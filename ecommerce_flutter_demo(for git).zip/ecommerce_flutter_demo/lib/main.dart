import 'package:animated_bottom_navigation_bar/animated_bottom_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(statusBarColor: Colors.white));
  runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Colors.white,
      ),
      home: HomePage()));
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage>
    with SingleTickerProviderStateMixin {
  TabController _tabController;
  ScrollController controller;
  PageController pageController = PageController();

  var _bottomNavIndex = 0; //default index of first screen
  final tabNameList = <String>['Home', 'Wishlist', 'Cart', 'Account'];
  final iconList = <IconData>[
    Icons.home_outlined,
    Icons.favorite_border,
    Icons.shopping_cart_outlined,
    Icons.account_circle,
  ];

  @override
  void initState() {
    _tabController = new TabController(length: 3, vsync: this);
    controller = ScrollController();
    //for automatic sliding
    // Timer.periodic(Duration(seconds: 3), (timer) {
    //   if (pageController.page >= 5 - 1) {
    //     pageController.animateToPage(0,
    //         duration: Duration(milliseconds: 1000),
    //         curve: Curves.fastLinearToSlowEaseIn);
    //   } else {
    //     pageController.nextPage(
    //         duration: Duration(milliseconds: 1000),
    //         curve: Curves.fastLinearToSlowEaseIn);
    //   }
    // });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      // set it to false
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            SizedBox(
              height: 130,
              child: Card(
                elevation: 0,
                child: Center(
                  child: ListTile(
                    leading: Icon(
                      Icons.account_circle,
                      size: 60,
                    ),
                    title: Text('Lio Tauhid'),
                    subtitle: Text('01633804493'),
                    // trailing: Icon(Icons.more_vert),
                    onTap: () {},
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Icon(
                    Icons.home,
                    size: 30,
                  ),
                  FlatButton(
                    onPressed: () {},
                    child: Text('Home'),
                    textColor: Colors.grey[700],
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Icon(
                    Icons.dashboard,
                    size: 30,
                  ),
                  FlatButton(
                    onPressed: () {},
                    child: Text('Dashboard'),
                    textColor: Colors.grey[700],
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Icon(
                    Icons.add_shopping_cart,
                    size: 30,
                  ),
                  FlatButton(
                    onPressed: () {},
                    child: Text('Cart'),
                    textColor: Colors.grey[700],
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Icon(
                    Icons.call,
                    size: 30,
                  ),
                  FlatButton(
                    onPressed: () {},
                    child: Text('Contact us'),
                    textColor: Colors.grey[700],
                  )
                ],
              ),
            ),
          ],
        ),
      ),
      body: NestedScrollView(
        controller: controller,
        headerSliverBuilder: (BuildContext context, bool boxIsScrolled) {
          return <Widget>[
            SliverAppBar(
              title: Container(
                padding: EdgeInsets.symmetric(horizontal: 8),
                decoration: BoxDecoration(
                    color: Colors.grey[100],
                    borderRadius: BorderRadius.all(Radius.circular(30))),
                child: TextFormField(
                  decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: 'What would you like to buy?',
                      hintStyle: TextStyle(color: Colors.black45),
                      icon: Icon(
                        Icons.search,
                        color: Colors.black54,
                      )),
                ),
              ),
              centerTitle: true,
              elevation: 0.0,
              pinned: true,
              floating: true,
              forceElevated: boxIsScrolled,
              actions: <Widget>[
                IconButton(
                  icon: Icon(
                    Icons.shopping_cart_outlined,
                    color: Colors.black54,
                  ),
                  onPressed: () {
                    // do something
                  },
                )
              ],
            ),
          ];
        },
        body: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.all(8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                LimitedBox(
                  maxHeight: 150,
                  child: Stack(
                    children: [
                      PageView(
                        controller: pageController,
                        children: [
                          ImageSliding(
                              'https://df17fp68uwcso.cloudfront.net/eyJidWNrZXQiOiAibWVkaWEuZXZhbHkuY29tLmJkIiwgImtleSI6ICJtZWRpYS9pbWFnZXMvNzBkNmFlYjRjYWY0LWY4OWM1OTQ2LWYyYTgtNGM3Zi05ZDYxLWU1YTVmNjM3Yjc5YS5qcGciLCAiZWRpdHMiOiB7InJlc2l6ZSI6IHsid2lkdGgiOiAxMzUwLCAiaGVpZ2h0IjogNDYwLCAiZml0IjogImNvbnRhaW4ifSwgImJhY2tncm91bmQiOiB7InIiOiAyNTUsICJnIjogMjU1LCAiYiI6IDI1NSwgImFscGhhIjogMX0sICJmbGF0dGVuIjogdHJ1ZSwgImpwZWciOiB7InF1YWxpdHkiOiA3NX19fQ=='),
                          ImageSliding(
                              'https://df17fp68uwcso.cloudfront.net/eyJidWNrZXQiOiAibWVkaWEuZXZhbHkuY29tLmJkIiwgImtleSI6ICJtZWRpYS9pbWFnZXMvMWM3YjNkNmJlYWE4LTQ1MTMyYWJjLWY3ZjYtNDBjMy05YzRkLTgyMzRhM2I5ZmZmNC5qcGciLCAiZWRpdHMiOiB7InJlc2l6ZSI6IHsid2lkdGgiOiAxMzUwLCAiaGVpZ2h0IjogNDYwLCAiZml0IjogImNvbnRhaW4ifSwgImJhY2tncm91bmQiOiB7InIiOiAyNTUsICJnIjogMjU1LCAiYiI6IDI1NSwgImFscGhhIjogMX0sICJmbGF0dGVuIjogdHJ1ZSwgImpwZWciOiB7InF1YWxpdHkiOiA3NX19fQ=='),
                          ImageSliding(
                              'https://df17fp68uwcso.cloudfront.net/eyJidWNrZXQiOiAibWVkaWEuZXZhbHkuY29tLmJkIiwgImtleSI6ICJtZWRpYS9pbWFnZXMvYWNmZDA2Y2IyMjZhLWQyYmFjYjU3LTg0NGEtNGY4Yy1iMzE3LTVjMDVkNDY0NDk1My5qcGciLCAiZWRpdHMiOiB7InJlc2l6ZSI6IHsid2lkdGgiOiAxMzUwLCAiaGVpZ2h0IjogNDYwLCAiZml0IjogImNvbnRhaW4ifSwgImJhY2tncm91bmQiOiB7InIiOiAyNTUsICJnIjogMjU1LCAiYiI6IDI1NSwgImFscGhhIjogMX0sICJmbGF0dGVuIjogdHJ1ZSwgImpwZWciOiB7InF1YWxpdHkiOiA3NX19fQ=='),
                          ImageSliding(
                              'https://df17fp68uwcso.cloudfront.net/eyJidWNrZXQiOiAibWVkaWEuZXZhbHkuY29tLmJkIiwgImtleSI6ICJtZWRpYS9pbWFnZXMvZjlmN2Y4MDgwMjVkLWE1MGQwYWExLTc0MGUtNDg5OS04ZDIzLTdmNWY3YWFmNWMyZi5qcGciLCAiZWRpdHMiOiB7InJlc2l6ZSI6IHsid2lkdGgiOiAxMzUwLCAiaGVpZ2h0IjogNDYwLCAiZml0IjogImNvbnRhaW4ifSwgImJhY2tncm91bmQiOiB7InIiOiAyNTUsICJnIjogMjU1LCAiYiI6IDI1NSwgImFscGhhIjogMX0sICJmbGF0dGVuIjogdHJ1ZSwgImpwZWciOiB7InF1YWxpdHkiOiA3NX19fQ=='),
                          ImageSliding(
                              'https://df17fp68uwcso.cloudfront.net/eyJidWNrZXQiOiAibWVkaWEuZXZhbHkuY29tLmJkIiwgImtleSI6ICJtZWRpYS9pbWFnZXMvZThlMGRlNTdhNGU1LTEyZGMzYTg3LTM5MDgtNDFjYS1hM2ZlLWI2YjY2N2I5YjcwYi5qcGciLCAiZWRpdHMiOiB7InJlc2l6ZSI6IHsid2lkdGgiOiAxMzUwLCAiaGVpZ2h0IjogNDYwLCAiZml0IjogImNvbnRhaW4ifSwgImJhY2tncm91bmQiOiB7InIiOiAyNTUsICJnIjogMjU1LCAiYiI6IDI1NSwgImFscGhhIjogMX0sICJmbGF0dGVuIjogdHJ1ZSwgImpwZWciOiB7InF1YWxpdHkiOiA3NX19fQ=='),
                        ],
                      ),
                      Positioned(
                          bottom: 18,
                          left: 0,
                          right: 0,
                          child: Center(child: SlideIndicator(pageController))),
                    ],
                  ),
                ),
                SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(
                      children: [
                        Container(
                            decoration: BoxDecoration(
                                color: Colors.grey[200],
                                borderRadius: BorderRadius.circular(100.0)),
                            child: IconButton(
                                icon: Icon(Icons.star),
                                color: Colors.pink,
                                onPressed: () {})),
                        Text("Popular")
                      ],
                    ),
                    Column(
                      children: [
                        Container(
                            decoration: BoxDecoration(
                                color: Colors.grey[200],
                                borderRadius: BorderRadius.circular(100.0)),
                            child: IconButton(
                                icon: Icon(Icons.access_alarm),
                                color: Colors.deepOrangeAccent,
                                onPressed: () {})),
                        Text("Flash Sale")
                      ],
                    ),
                    Column(
                      children: [
                        Container(
                            decoration: BoxDecoration(
                                color: Colors.grey[200],
                                borderRadius: BorderRadius.circular(100.0)),
                            child: IconButton(
                                icon: Icon(Icons.store),
                                color: Colors.cyan,
                                onPressed: () {})),
                        Text("Evaly Store")
                      ],
                    ),
                    Column(
                      children: [
                        Container(
                            decoration: BoxDecoration(
                                color: Colors.grey[200],
                                borderRadius: BorderRadius.circular(100.0)),
                            child: IconButton(
                                icon: Icon(Icons.local_offer_outlined),
                                color: Colors.cyanAccent,
                                onPressed: () {})),
                        Text("Voucher")
                      ],
                    ),
                    Column(
                      children: [
                        Container(
                            decoration: BoxDecoration(
                                color: Colors.grey[200],
                                borderRadius: BorderRadius.circular(100.0)),
                            child: IconButton(
                                icon: Icon(Icons.card_giftcard),
                                color: Colors.pinkAccent,
                                onPressed: () {})),
                        Text("Gift")
                      ],
                    ),
                  ],
                ),
                SizedBox(height: 20),
                TabBar(
                  indicatorColor: Colors.pink[600],
                  tabs: [
                    Tab(
                      text: 'Category',
                    ),
                    Tab(
                      text: 'Brands',
                    ),
                    Tab(
                      text: 'Shops',
                    )
                  ],
                  controller: _tabController,
                ),
                SizedBox(height: 10),
                Container(
                  height: 230,
                  child: TabBarView(
                    children: [
                      Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              setTabRowItem('Bag & Luggage', Icons.shopping_bag,
                                  Colors.blueGrey),
                              setTabRowItem(
                                  'Beauty & Body',
                                  Icons.accessibility_rounded,
                                  Colors.cyanAccent),
                              setTabRowItem(
                                  'Books', Icons.book, Colors.deepPurpleAccent)
                            ],
                          ),
                          SizedBox(height: 5),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              setTabRowItem('Burmese Products',
                                  Icons.card_giftcard, Colors.red),
                              setTabRowItem('Material', Icons.construction,
                                  Colors.orange),
                              setTabRowItem('Decoration Material',
                                  Icons.ac_unit, Colors.purpleAccent)
                            ],
                          ),
                        ],
                      ),
                      Text('Brands'),
                      Text('Shops')
                    ],
                    controller: _tabController,
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Flash Sale',
                      style: TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.grey[700]),
                    ),
                    FlatButton(
                      child: Text('Show All'),
                      textColor: Colors.grey[600],
                      onPressed: () {},
                    ),
                  ],
                ),
                Container(
                  height: 220,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: <Widget>[
                      setFlashSale("Woolen Sleeve Sweater For Women", "140",
                          "https://s3-ap-southeast-1.amazonaws.com/media.evaly.com.bd/media/images/a69670d5ad2b-34.jpg"),
                      setFlashSale("Woolen Sleeve Sweater For Women", "140",
                          "https://s3-ap-southeast-1.amazonaws.com/media.evaly.com.bd/media/images/f959f36584cf-36.jpg"),
                      setFlashSale("Woolen Sleeve Sweater For Women", "140",
                          "https://s3-ap-southeast-1.amazonaws.com/media.evaly.com.bd/media/images/1b0c3daa1430-32.jpg"),
                      setFlashSale("Woolen Sleeve Sweater For Women", "140",
                          "https://s3-ap-southeast-1.amazonaws.com/media.evaly.com.bd/media/images/a69670d5ad2b-34.jpg"),
                    ],
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Evaly Express',
                      style: TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.grey[700]),
                    ),
                    FlatButton(
                      child: Text('Show All'),
                      textColor: Colors.grey[600],
                      onPressed: () {},
                    ),
                  ],
                ),
                Container(
                  height: 100,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: <Widget>[
                      evalyExpress("eFood",
                          'https://evaly.com.bd/static/images/express/express_food.png'),
                      evalyExpress("Shwapno Express",
                          'https://evaly.com.bd/static/images/express/express_shwapno.png'),
                      evalyExpress("Meena Click",
                          'https://evaly.com.bd/static/images/express/express_meena.png'),
                      evalyExpress("Bengal Meat",
                          'https://evaly.com.bd/static/images/express/express_bengal_meat.png'),
                      evalyExpress("eFood",
                          'https://evaly.com.bd/static/images/express/express_food.png'),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        tooltip: 'Increment',
        child: Icon(Icons.star),
        elevation: 2.0,
      ),
      bottomNavigationBar: AnimatedBottomNavigationBar.builder(
        itemCount: iconList.length,
        tabBuilder: (int index, bool isActive) {
          final color = isActive ? Colors.red : Colors.grey;
          return Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                iconList[index],
                size: 24,
                color: color,
              ),
              const SizedBox(height: 4),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Text(
                  tabNameList[index],
                  maxLines: 1,
                  style: TextStyle(color: color),
                ),
              )
            ],
          );
        },
        activeIndex: _bottomNavIndex,
        gapLocation: GapLocation.center,
        notchSmoothness: NotchSmoothness.softEdge,
        leftCornerRadius: 0,
        rightCornerRadius: 0,
        onTap: (index) {
          setState(() => _bottomNavIndex = index);
          print(index);
        },
        //other params
      ),
    );
  }

  Widget evalyExpress(String name, String link) {
    return Container(
      padding: EdgeInsets.all(2),
      child: Column(
        children: [
          SizedBox(
              height: 75,
              width: 100,
              child: ClipRRect(
                  borderRadius: BorderRadius.all(Radius.circular(12)),
                  child: Image(image: NetworkImage(link)))),
          Text(name)
        ],
      ),
    );
  }

  Widget setTabRowItem(String type, IconData iconData, Color color) {
    return Padding(
      padding: const EdgeInsets.all(5),
      child: Column(
        children: [
          Container(
              height: 100,
              width: 110,
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10.0)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                      icon: Icon(
                        iconData,
                        size: 35,
                      ),
                      color: color,
                      alignment: Alignment.topLeft,
                      onPressed: () {}),
                  Text(
                    type,
                    textAlign: TextAlign.center,
                  ),
                ],
              )),
        ],
      ),
    );
  }

  Widget setFlashSale(String text, String tk, String link) {
    return Padding(
      padding: const EdgeInsets.all(5),
      child: Column(
        children: [
          Container(
              height: 210,
              width: 140,
              padding: EdgeInsets.all(5),
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10.0)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                      height: 100,
                      width: 100,
                      child: Image(image: NetworkImage(link))),
                  Text(
                    text,
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    'tk ' + tk,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Colors.deepOrange, fontWeight: FontWeight.bold),
                  ),
                ],
              )),
        ],
      ),
    );
  }
}

class SlideIndicator extends AnimatedWidget {
  PageController pageController;

  SlideIndicator(this.pageController) : super(listenable: pageController);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List<Widget>.generate(5, buildIndicator),
    );
  }

  Widget buildIndicator(int index) {
    print(index);
    bool active = pageController.page == index;
    return Container(
      width: 30,
      child: Center(
        child: Container(
          height: 8,
          width: 8,
          decoration: BoxDecoration(
              color: active ? Colors.lightBlue : Colors.grey,
              borderRadius: BorderRadius.circular(10)),
        ),
      ),
    );
  }
}

// ignore: must_be_immutable
class ImageSliding extends StatelessWidget {
  String imageLink;

  ImageSliding(this.imageLink);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(5),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Image.network(
          imageLink,
          fit: BoxFit.fill,
        ),
      ),
    );
  }
}
